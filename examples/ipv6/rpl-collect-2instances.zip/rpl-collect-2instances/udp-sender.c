/*
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the Institute nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE INSTITUTE AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * This file is part of the Contiki operating system.
 *
 */

#include "contiki.h"
#include "lib/random.h"
#include "sys/ctimer.h"
#include "net/uip.h"
#include "net/uip-ds6.h"
#include "net/uip-udp-packet.h"
#include "sys/ctimer.h"
//#include "powertrace.h"
#include <stdio.h>
#include <string.h>

#define UDP_CLIENT_PORT 8765
#define UDP_SERVER_PORT 5678

#define UDP_EXAMPLE_ID  190
#define UIP_IP_BUF   ((struct uip_ip_hdr *)&uip_buf[UIP_LLH_LEN])
#define DEBUG DEBUG_PRINT
#include "net/uip-debug.h"
static struct uip_udp_conn *client_conn;
static uip_ipaddr_t server_ipaddr;
 typedef struct sender_statistics {
	 /**
	  *
	  * senders statistics
	  *
	  */
    uint8_t nodeID;
	uint8_t resID; // response ID ??
	uint8_t seq; // Sequence
	uint32_t senderlastTX;	// time of the last response that has been sent from the sender (ms)
	uint32_t senderlastRX;	// time of the last request that has been received from the sink (ms)
	uint8_t numReq;			// number of request received at the sender
	uint16_t sinkMinTX;	// minimum TX time of the request from the sink to the sender
	uint16_t sinkMaxTX;	// maximum TX time of the request from the sink to the sender
	uint16_t sinkTotTX;	// total TX time of the request from the sink to the sender
} sender_statistics_t;
static sender_statistics_t nodeInf;
/*---------------------------------------------------------------------------*/
PROCESS(udp_client_process, "UDP client process");
AUTOSTART_PROCESSES(&udp_client_process);
/*
 * Changed
 * get_time in milliseconds
 *
 */
static clock_time_t
get_time_ms(void)
{
/*Get time in milliseconds
* typedef unsigned long clock_time_t;
* CLOCK_CONF_SECOND is number of ticks per second; for z1: 128UL
* clock_time()*1000UL returns current number of ticks from starting time of the mote
* */
return (clock_time_t)((clock_time()*1000UL)/CLOCK_CONF_SECOND);
}
/*
 *
 * send the packet per instance
 */
static void
packet_send(uint8_t instance_id)
{
	static uint8_t seqno;
	struct {
		uint8_t instance_id; // instance id
		uint8_t seqno;  // sequence number
		uint8_t resID;  // request id
		uint8_t numReq; // number of received request
		uint32_t senderlastRX; // sender last time  recieved
		uint32_t senderlastTX; // sender last time transmitted  both necessary for transmission
		uint8_t  padding[18];
	} msg;
	if(client_conn == NULL) {
		/* Not setup yet */
		return;
	}
	memset(&msg, 0, sizeof(msg));
	seqno++;
	if(seqno == 0) {
		/* Wrap to 128 to identify restarts */
		seqno = 128;
	}
	msg.seqno = seqno;
	msg.resID = nodeInf.resID;
	msg.instance_id = instance_id;
	msg.numReq = nodeInf.numReq;
	uint32_t time = get_time_ms();
	msg.senderlastRX = nodeInf.senderlastRX;
	msg.senderlastTX = time;
	nodeInf.senderlastTX = time;
	uip_ipaddr_copy(&client_conn->ripaddr, &UIP_IP_BUF->srcipaddr);
		uip_udp_packet_send(client_conn, &msg, sizeof(msg));
		uip_udp_packet_sendto(client_conn, &msg, sizeof(msg),
				&server_ipaddr, UIP_HTONS(UDP_SERVER_PORT));
	printf ("TX: Time : %lu resID: %u numReq: %u\n", time, msg.resID, msg.numReq);



//	printf("sizeof %u , %u, %u, %u, %u \n",sizeof(uint8_t), sizeof(uint16_t), sizeof(uint32_t), sizeof(msg));

}
/*---------------------------------------------------------------------------*/
static void
tcpip_handler(void)
{
    uint8_t *appdata;
    uint8_t reqID;
    uint8_t instance_id;
  	uint32_t sinklastTX;
  	if(uip_newdata()) {
  			// Collect data from received payload
  			appdata = (uint8_t *)uip_appdata;
  		   // printf("sizeof(appdata): %u\n", uip_datalen());
  		    reqID = *appdata; // Check for next lines
  		    appdata++;//
  		    instance_id = *appdata;
  		    appdata++; //
  			memcpy(&sinklastTX, appdata, 4);

  			//Get the time for receiving response
  					uint32_t time = get_time_ms();

  					// Updating statistics information for the node
  			//		PRINTF("Updating statistics information\n");

  					if (nodeInf.nodeID == 0){ // get nodeId for the first time
  						uip_ds6_addr_t *addr;
  						addr = uip_ds6_get_link_local(-1);
  						nodeInf.nodeID = (addr->ipaddr.u8[sizeof(uip_ipaddr_t) - 2]<<8) + addr->ipaddr.u8[sizeof(uip_ipaddr_t) - 1];
  					}

  					uint8_t oldresID = nodeInf.resID; // Store the resID
  					nodeInf.senderlastRX = time;
  					/*if (nodeInf.resID==0){ // first time received a request

  					} else { // received at least one request

  					}*/
  					nodeInf.resID = reqID; // Update resID to be identical with its request's ID
  			//		nodeInf.senderlastTX = time;
  					nodeInf.numReq++;
  					uint16_t sinkTX = (uint16_t)(time - sinklastTX) & 0xffff;
  					if (nodeInf.sinkMinTX > sinkTX){
  						nodeInf.sinkMinTX = sinkTX;
  					}
  					if (nodeInf.sinkMaxTX < sinkTX){
  						nodeInf.sinkMinTX = sinkTX;
  					}


  				   packet_send(30);

  	}
}
/*-------------------------------------------*/
static void
print_local_addresses(void)
{

}
/*---------------------------------------------------------------------------*/
static void
set_global_address(void)
{
  uip_ipaddr_t ipaddr;

  uip_ip6addr(&ipaddr, 0xaaaa, 0, 0, 0, 0, 0, 0, 0);
  uip_ds6_set_addr_iid(&ipaddr, &uip_lladdr);
  uip_ds6_addr_add(&ipaddr, 0, ADDR_AUTOCONF);

/* The choice of server address determines its 6LoPAN header compression.
 * (Our address will be compressed Mode 3 since it is derived from our link-local address)
 * Obviously the choice made here must also be selected in udp-server.c.
 *
 * For correct Wireshark decoding using a sniffer, add the /64 prefix to the 6LowPAN protocol preferences,
 * e.g. set Context 0 to aaaa::.  At present Wireshark copies Context/128 and then overwrites it.
 * (Setting Context 0 to aaaa::1111:2222:3333:4444 will report a 16 bit compressed address of aaaa::1111:22ff:fe33:xxxx)
 *
 * Note the IPCMV6 checksum verification depends on the correct uncompressed addresses.
 */

#if 0
/* Mode 1 - 64 bits inline */
   uip_ip6addr(&server_ipaddr, 0xaaaa, 0, 0, 0, 0, 0, 0, 1);
#elif 1
/* Mode 2 - 16 bits inline */
  uip_ip6addr(&server_ipaddr, 0xaaaa, 0, 0, 0, 0, 0x00ff, 0xfe00, 1);
#else
/* Mode 3 - derived from server link-local (MAC) address */
  uip_ip6addr(&server_ipaddr, 0xaaaa, 0, 0, 0, 0x0250, 0xc2ff, 0xfea8, 0xcd1a); //redbee-econotag
#endif
}
/*---------------------------------------------------------------------------*/
PROCESS_THREAD(udp_client_process, ev, data)
{
  PROCESS_BEGIN();

  PROCESS_PAUSE();
  //powertrace_start(CLOCK_SECOND * 2);

  set_global_address();

  PRINTF("UDP client process started\n");

  print_local_addresses();

/*
	 The data sink runs with a 100% duty cycle in order to ensure high
	 packet reception rates.
	NETSTACK_MAC.off(1)*/;

  /* new connection with remote host */

	NETSTACK_MAC.off(1);
  client_conn = udp_new(NULL, UIP_HTONS(UDP_SERVER_PORT), NULL);
  if(client_conn == NULL) {
    PRINTF("No UDP connection available, exiting the process!\n");
    PROCESS_EXIT();
  }
  udp_bind(client_conn, UIP_HTONS(UDP_CLIENT_PORT));

  PRINTF("Created a connection with the server ");
  PRINT6ADDR(&client_conn->ripaddr);
  PRINTF(" local/remote port %u/%u\n",
	UIP_HTONS(client_conn->lport), UIP_HTONS(client_conn->rport));


  while(1) {
 // PROCESS_YIELD();

  PROCESS_WAIT_EVENT_UNTIL(ev == tcpip_event);

        tcpip_handler();
  //packet_send(30);
  }
  PROCESS_END();
}
/*---------------------------------------------------------------------------*/
